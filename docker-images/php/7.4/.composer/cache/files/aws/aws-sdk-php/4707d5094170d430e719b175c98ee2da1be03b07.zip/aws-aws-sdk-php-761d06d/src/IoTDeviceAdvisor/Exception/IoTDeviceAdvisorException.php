<?php
namespace Aws\IoTDeviceAdvisor\Exception;

use Aws\Exception\AwsException;

/**
 * Represents an error interacting with the **AWS IoT Core Device Advisor** service.
 */
class IoTDeviceAdvisorException extends AwsException {}
