<?php

require_once 'autoload.php';
ParagonIE_Sodium_Compat::$fastMult = true;
